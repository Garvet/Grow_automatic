#include "build_data.h"

#if defined( SEND_SERVER )

#if defined( BUILD_BASEMENT )
#define BASEMENT
#else
// #define ROOM202
#define ROOM213
#endif

#if defined( BUILD_BASEMENT )

#if defined( BASEMENT_LOCAL_SERVER )
#define SERVER_LOCAL
#else
#define SERVER_GLOBAL
#endif

#else

#if defined( SEND_GLOBAL_SERVER )
#define SERVER_GLOBAL
#else
#define SERVER_MY_PC
#endif

#endif

#if defined( BUILD_BASEMENT ) || defined( SEND_GLOBAL_SERVER )
#define PORT_WORK_SERVER
#else
#define PORT_TEST_SERVER
#endif

#if defined( ROOM202 )
const std::array<char, AMT_BYTES_NETWORK_NAME> network_name = {"a202"};
const std::array<char, AMT_BYTES_NETWORK_PASSWORD> network_pswd = {"gamma113"};
#endif
#if defined( ROOM213 )
const std::array<char, AMT_BYTES_NETWORK_NAME> network_name = {"213_Guest"};
const std::array<char, AMT_BYTES_NETWORK_PASSWORD> network_pswd = {"11081975"};
#endif
#if defined( BASEMENT )
const std::array<char, AMT_BYTES_NETWORK_NAME> network_name = {"dd-wrt"};
const std::array<char, AMT_BYTES_NETWORK_PASSWORD> network_pswd = {""};
#endif

#if defined( SERVER_GLOBAL )

#if ( NUM_GLOBAL_SERVER == 1 )
const std::array<char, AMT_BYTES_NETWORK_ADDRESS> server_address = {"95.181.230.220"};
#elif ( NUM_GLOBAL_SERVER == 2 )
const std::array<char, AMT_BYTES_NETWORK_ADDRESS> server_address = {"31.31.202.109"};
#endif

#endif
#if defined( SERVER_LOCAL )
const std::array<char, AMT_BYTES_NETWORK_ADDRESS> server_address = {"192.168.0.139"};
#endif
#if defined( SERVER_MY_PC )
const std::array<char, AMT_BYTES_NETWORK_ADDRESS> server_address = {"192.168.1.37"}; // "192.168.1.72" - кабедь ; // "192.168.1.37" - WiFi;
#endif

#if defined( PORT_WORK_SERVER )
const int server_port = 3333;
#endif
#if defined( PORT_TEST_SERVER )
// const int server_port = 7584;
const int server_port = 3334;
#endif

#endif
