#include <Arduino.h>
#include "additional_functionality.hpp"

extern uint8_t data[100];