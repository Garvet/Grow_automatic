#include "Time_control.h"

Time_control::Time_control() {
}

Time_control::~Time_control() {
}